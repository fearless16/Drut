import React from 'react'
import './App.css'

function App() {
  return <h1>Hello, Vite!</h1>
}

export default App
